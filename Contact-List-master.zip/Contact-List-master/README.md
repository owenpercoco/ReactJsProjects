# Contact-List
A simple react based program to access a firebase database, storing a contact list.  Uses the flux architecture as well.
